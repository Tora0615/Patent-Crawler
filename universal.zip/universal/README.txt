更改 setting.txt 內容後
執行 Python 檔就可以了
(開啟 PowerShell 輸入指令 : python [路徑]\crawler.py )
(範例 : python C:\Users\User\Desktop\universal_craeler\crawler.py)

第一行是某公司 "第一筆資料" 的網址
第二行是起始編號 (如1)
第三行是終止編號 (如100)

結果出來的資料中，偶爾會有 "&nbsp"
這在網頁上代表的是空白
建議要在 Excel 取代為真正的空白

例子 : 
C07D 471/04&nbsp(20130101) 實際上為
C07D 471/04 (20130101)
